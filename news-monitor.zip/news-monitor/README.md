# Новостной монитор — версия 0.1

Следит за анонсами бирж, записывает каждое событие с ценой монеты в момент получения,
шлёт уведомление в Telegram и через 1, 5, 30 и 60 минут сам дописывает, куда пошла цена.

## Что уже работает

| Модуль | Источник | Как |
| --- | --- | --- |
| Анонсы Bybit | `/v5/announcements/index` | опрос раз в 1 с |
| Анонсы OKX | `/api/v5/support/announcements` | опрос раз в 1 с |
| Анонсы Binance | WebSocket `com_announcement_en` | push, **только если задан API-ключ** |
| Цены всего рынка | Binance Futures + Binance Spot (WebSocket), Bybit (REST, раз в 2 с) | |
| Классификация | правила: листинг, делистинг, взлом, фьючерсы, monitoring tag… | микросекунды |
| Замер реакции | цена через 1 / 5 / 30 / 60 мин | переживает перезапуск |
| Здоровье | уведомление, если источник молчит дольше 90 с | |

При первом запуске каждый источник делает «базовую загрузку»: уже опубликованные анонсы
пишутся в базу без уведомлений. Дальше приходят только новые.

## Установка на сервер (Ubuntu / Debian)

```bash
# 1. скопировать архив на сервер и распаковать
scp news-monitor.zip root@IP_СЕРВЕРА:/root/
ssh root@IP_СЕРВЕРА
apt-get install -y unzip && unzip news-monitor.zip && cd news-monitor

# 2. сначала проверить, что биржи отвечают с этого сервера
apt-get install -y python3-venv && python3 -m venv /tmp/v && /tmp/v/bin/pip install aiohttp
/tmp/v/bin/python -m monitor.check

# 3. установить как службу
sudo bash deploy/install.sh
nano /opt/news-monitor/.env          # TG_BOT_TOKEN и TG_CHAT_ID
systemctl start news-monitor
journalctl -u news-monitor -f        # живой лог
```

**Где взять TG_CHAT_ID:** напишите своему боту любое сообщение, затем откройте в браузере
`https://api.telegram.org/bot<ТОКЕН>/getUpdates` — число в `"chat":{"id": ...}`.

## Статистика

```bash
cd /opt/news-monitor && venv/bin/python -m monitor.stats data/monitor.db
```

Покажет задержку каждого источника (медиана и p95) и среднюю реакцию цены по типам событий.

## Известные ограничения версии 0.1

- **Цена новых монет.** При анонсе листинга монеты часто ещё нет ни на Binance, ни на Bybit —
  тогда замер реакции пропускается. Следующий шаг — цены с DEX (DexScreener).
- **Binance Announcements** требует API-ключ (только чтение, без права торговли).
  Формат сообщений сверен по SDK; если парсер что-то не поймёт, в логе будет строка
  `binance: не разобрал сообщение` — пришлите её.
- **Upbit** пока не подключён (нужен ключ Upbit).
- Адреса WebSocket Binance можно переопределить в `.env` (`BINANCE_FUTURES_WS`, `BINANCE_SPOT_WS`),
  если биржа их сменит.

## Тесты

```bash
python3 -m unittest discover -s tests -t .
```
