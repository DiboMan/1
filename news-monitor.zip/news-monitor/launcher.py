#!/usr/bin/env python3
"""Стабильный запускатор. Не обновляется вместе с ботом по ходу работы.

Если после обновления новая версия падает в первые 2 минуты, launcher
возвращает прошлую версию из monitor.bak и сообщает об этом в Telegram.
Только стандартная библиотека — работает, даже если новый код сломан.
"""
import json
import os
import runpy
import shutil
import sys
import time
import traceback
import urllib.parse
import urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
FLAG = os.path.join(APP, "data", "update_pending")
CRASH_WINDOW_SEC = 120


def notify(text: str):
    token, chat = os.environ.get("TG_BOT_TOKEN", "").strip(), os.environ.get("TG_CHAT_ID", "").strip()
    if not (token and chat):
        return
    data = urllib.parse.urlencode({"chat_id": chat, "text": text[:3900]}).encode()
    try:
        urllib.request.urlopen(f"https://api.telegram.org/bot{token}/sendMessage", data, timeout=10)
    except Exception:
        pass


def rollback_after_crash(tb: str):
    cur, bak = os.path.join(APP, "monitor"), os.path.join(APP, "monitor.bak")
    if not os.path.isdir(bak):
        notify("⚠️ Новая версия упала при запуске, а резервной копии нет:\n" + tb[-1500:])
        return
    broken = cur + ".broken"
    shutil.rmtree(broken, ignore_errors=True)
    shutil.move(cur, broken)
    shutil.move(bak, cur)
    try:
        os.remove(FLAG)
    except OSError:
        pass
    notify("⚠️ Новая версия упала при запуске — вернул прошлую. Ошибка:\n" + tb[-1500:])


def main():
    sys.path.insert(0, APP)
    os.chdir(APP)
    started = time.time()
    try:
        runpy.run_module("monitor", run_name="__main__", alter_sys=True)
    except SystemExit:
        raise
    except BaseException:
        tb = traceback.format_exc()
        if os.path.exists(FLAG) and time.time() - started < CRASH_WINDOW_SEC:
            rollback_after_crash(tb)
        raise


if __name__ == "__main__":
    main()
