"""Тесты без сети: python -m unittest discover -s tests"""
import json
import os
import tempfile
import time
import unittest

from monitor.classify import classify, extract_tickers
from monitor.config import Config
from monitor.db import Store
from monitor.parsers import parse_binance_ws, parse_bybit, parse_okx
from monitor.pipeline import Pipeline


class FakeNotifier:
    def __init__(self):
        self.sent = []

    def send(self, text):
        self.sent.append(text)


class FakeBook:
    def __init__(self, prices):
        self.p = prices          # key -> price
        self.last_update = {}

    def lookup(self, t):
        for key in (f"bnf:{t}USDT", f"bns:{t}USDT"):
            if key in self.p:
                return self.p[key], key
        return None

    def get_key(self, key):
        return self.p.get(key)


def now():
    return int(time.time() * 1000)


class ClassifyTest(unittest.TestCase):
    def test_categories(self):
        self.assertEqual(classify("Binance Will List Foo (FOO)")[0], "listing")
        self.assertEqual(classify("Binance Will Delist ABC, DEF on 2026-11-20")[0], "delisting")
        self.assertEqual(classify("Binance Futures Will Launch USDⓈ-M FOOUSDT Perpetual Contract")[0],
                         "futures_launch")
        self.assertEqual(classify("Security incident: suspicious withdrawals detected")[0], "hack")
        self.assertEqual(classify("Wallet maintenance for SOL network")[1], "low")
        self.assertEqual(classify("Some title", hint="new_crypto"), ("listing", "high"))
        # взлом в тексте важнее «скучной» подсказки биржи
        self.assertEqual(classify("Exchange hack: deposits suspended", hint="maintenance_updates")[0], "hack")

    def test_tickers(self):
        self.assertEqual(extract_tickers("Binance Will List Foo (FOO) and Bar (BAR)"), ["FOO", "BAR"])
        self.assertEqual(extract_tickers("Launch FOOUSDT Perpetual"), ["FOO"])
        self.assertEqual(extract_tickers("Update (USDT) (API) maintenance"), [])
        self.assertIn("BTC", extract_tickers("Bitcoin (BTC) network upgrade"))


class ParserTest(unittest.TestCase):
    def test_bybit(self):
        evs = parse_bybit({"retCode": 0, "result": {"list": [{
            "title": "New Listing: FOO", "url": "https://x/1", "publishTime": 1700000000000,
            "type": {"key": "new_crypto"}, "description": "d"}]}})
        self.assertEqual((evs[0].ext_id, evs[0].hint, evs[0].published_ms),
                         ("https://x/1", "new_crypto", 1700000000000))
        with self.assertRaises(ValueError):
            parse_bybit({"retCode": 10006, "retMsg": "rate limit"})

    def test_okx(self):
        evs = parse_okx({"code": "0", "data": [{"details": [{
            "annType": "announcements-new-listings", "pTime": "1700000000000",
            "title": "OKX to list FOO", "url": "https://okx/1"}]}]})
        self.assertEqual(evs[0].published_ms, 1700000000000)

    def test_binance_string_data(self):
        inner = json.dumps({"catalogName": "New Cryptocurrency Listing", "publishDate": 1700000000000,
                            "title": "Binance Will List FOO (FOO)", "body": "..."})
        evs = parse_binance_ws(json.dumps({"type": "DATA", "data": inner}))
        self.assertEqual(evs[0].title, "Binance Will List FOO (FOO)")
        self.assertEqual(parse_binance_ws(json.dumps({"type": "COMMAND", "data": "SUCCESS"})), [])


class PipelineTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = Config()
        self.cfg.db_path = os.path.join(self.tmp, "t.db")
        self.store = Store(self.cfg.db_path)
        self.book = FakeBook({"bnf:FOOUSDT": 2.0})
        self.tg = FakeNotifier()
        self.pipe = Pipeline(self.cfg, self.store, self.book, self.tg)

    def raw(self, ext, title, published=None):
        from monitor.models import RawEvent
        return RawEvent(source="bybit", ext_id=ext, title=title, url="u", published_ms=published)

    def test_baseline_then_live(self):
        t = now()
        # первая пачка — базовая загрузка, без уведомлений
        self.assertEqual(self.pipe.handle_batch("bybit", [self.raw("a", "Will List Old (OLD)", t)], t), [])
        # вторая пачка: старое пропускается, новое уходит в уведомления
        alerted = self.pipe.handle_batch(
            "bybit", [self.raw("a", "Will List Old (OLD)", t), self.raw("b", "Will List Foo (FOO)", t - 800)], t)
        self.assertEqual(len(alerted), 1)
        self.assertEqual(alerted[0].prices, {"FOO": [2.0, "bnf:FOOUSDT"]})
        self.assertEqual(alerted[0].latency_ms, 800)
        self.assertTrue(any("Foo" in s for s in self.tg.sent))

    def test_stale_announcement_not_alerted(self):
        t = now()
        self.pipe.handle_batch("bybit", [self.raw("a", "x", t)], t)
        old = t - 3 * 3600_000
        self.assertEqual(self.pipe.handle_batch("bybit", [self.raw("z", "Will List Z (FOO)", old)], t), [])

    def test_restart_does_not_realert(self):
        t = now()
        self.pipe.handle_batch("bybit", [self.raw("a", "x", t)], t)
        self.pipe.handle_batch("bybit", [self.raw("b", "Will List Foo (FOO)", t)], t)
        pipe2 = Pipeline(self.cfg, Store(self.cfg.db_path), self.book, FakeNotifier())
        self.assertEqual(pipe2.handle_batch("bybit", [self.raw("b", "Will List Foo (FOO)", t)], t), [])

    def test_reactions(self):
        t = now()
        self.pipe.handle_batch("bybit", [self.raw("a", "x", t)], t)
        self.pipe.handle_batch("bybit", [self.raw("b", "Will List Foo (FOO)", t)], t - 6 * 60_000)
        self.book.p["bnf:FOOUSDT"] = 2.2
        self.pipe.measure_reactions()
        rows = self.store.conn.execute(
            "SELECT horizon_min, round(ret_pct, 4) FROM reactions ORDER BY horizon_min").fetchall()
        self.assertEqual(rows, [(1, 10.0), (5, 10.0)])
        # повторный вызов не дублирует замеры
        self.pipe.measure_reactions()
        self.assertEqual(self.store.conn.execute("SELECT COUNT(*) FROM reactions").fetchone()[0], 2)
        from monitor.stats import report
        self.assertIn("listing", report(self.cfg.db_path))


if __name__ == "__main__":
    unittest.main()
