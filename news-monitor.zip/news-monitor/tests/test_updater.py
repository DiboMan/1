"""Тесты обновления и автоотката (без сети)."""
import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

from monitor import updater

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def make_zip(files: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, body in files.items():
            z.writestr(name, body)
    return buf.getvalue()


class UpdaterTest(unittest.TestCase):
    def setUp(self):
        self.app = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.app, "monitor"))
        with open(os.path.join(self.app, "monitor", "__init__.py"), "w") as f:
            f.write('__version__ = "0.1"\n')
        with open(os.path.join(self.app, "monitor", "__main__.py"), "w") as f:
            f.write("print('old')\n")

    def tearDown(self):
        shutil.rmtree(self.app, ignore_errors=True)

    def test_apply_and_rollback(self):
        blob = make_zip({
            "news-monitor/monitor/__init__.py": '__version__ = "0.2"\n',
            "news-monitor/monitor/__main__.py": "print('new')\n",
            "news-monitor/launcher.py": "# launcher\n",
        })
        v = updater.apply_update(blob, self.app)
        self.assertEqual(v, {"old": "0.1", "new": "0.2"})
        self.assertEqual(updater.read_version(os.path.join(self.app, "monitor")), "0.2")
        self.assertEqual(updater.read_version(os.path.join(self.app, "monitor.bak")), "0.1")
        self.assertTrue(os.path.isfile(os.path.join(self.app, "launcher.py")))
        self.assertEqual(updater.read_flag(self.app)["new"], "0.2")
        r = updater.rollback(self.app)
        self.assertEqual(r["new"], "0.1")
        self.assertEqual(updater.read_version(os.path.join(self.app, "monitor")), "0.1")
        self.assertEqual(updater.read_version(os.path.join(self.app, "monitor.bak")), "0.2")

    def test_rejects_broken_code(self):
        blob = make_zip({"monitor/__init__.py": "", "monitor/__main__.py": "def broken(:\n"})
        with self.assertRaises(updater.UpdateError):
            updater.apply_update(blob, self.app)
        # старая версия не тронута
        self.assertEqual(updater.read_version(os.path.join(self.app, "monitor")), "0.1")
        self.assertIsNone(updater.read_flag(self.app))

    def test_rejects_garbage_and_traversal(self):
        with self.assertRaises(updater.UpdateError):
            updater.apply_update(b"not a zip", self.app)
        with self.assertRaises(updater.UpdateError):
            updater.apply_update(make_zip({"../evil.py": "x"}), self.app)
        with self.assertRaises(updater.UpdateError):
            updater.apply_update(make_zip({"other/file.py": "x = 1\n"}), self.app)


class LauncherTest(unittest.TestCase):
    def test_crash_after_update_rolls_back(self):
        app = tempfile.mkdtemp()
        try:
            shutil.copy(os.path.join(HERE, "launcher.py"), app)
            os.makedirs(os.path.join(app, "monitor"))
            os.makedirs(os.path.join(app, "monitor.bak"))
            os.makedirs(os.path.join(app, "data"))
            with open(os.path.join(app, "monitor", "__init__.py"), "w") as f:
                f.write('__version__ = "bad"\n')
            with open(os.path.join(app, "monitor", "__main__.py"), "w") as f:
                f.write("raise RuntimeError('boom')\n")
            with open(os.path.join(app, "monitor.bak", "__init__.py"), "w") as f:
                f.write('__version__ = "good"\n')
            with open(os.path.join(app, "monitor.bak", "__main__.py"), "w") as f:
                f.write("print('ok')\n")
            open(os.path.join(app, "data", "update_pending"), "w").write("{}")

            env = {k: v for k, v in os.environ.items() if not k.startswith("TG_")}
            r = subprocess.run([sys.executable, "launcher.py"], cwd=app, env=env,
                               capture_output=True, text=True)
            self.assertNotEqual(r.returncode, 0)          # упал — systemd перезапустит
            self.assertEqual(updater.read_version(os.path.join(app, "monitor")), "good")
            self.assertFalse(os.path.exists(os.path.join(app, "data", "update_pending")))
            # второй запуск уже на старой версии
            r = subprocess.run([sys.executable, "launcher.py"], cwd=app, env=env,
                               capture_output=True, text=True)
            self.assertEqual((r.returncode, r.stdout.strip()), (0, "ok"))
        finally:
            shutil.rmtree(app, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
