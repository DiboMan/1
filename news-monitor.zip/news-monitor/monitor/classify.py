"""Быстрая классификация по правилам: работает за микросекунды, без сети.

LLM подключим позже отдельным шагом — она будет уточнять категорию
асинхронно, не задерживая уведомление.
"""
import re

IMPORTANCE_ORDER = {"low": 0, "medium": 1, "high": 2}

# (категория, важность, регулярки). Порядок важен: первое совпадение побеждает.
RULES = [
    ("hack", "high", [
        r"\bhack", r"exploit", r"security incident", r"stolen", r"unauthori[sz]ed",
        r"suspicious (?:activity|withdrawal)",
    ]),
    ("delisting", "high", [
        r"\bdelist", r"will (?:remove|cease)", r"cease trading", r"removal of",
        r"discontinu", r"trading support (?:end|termination)",
    ]),
    ("listing", "high", [
        r"will list", r"new listing", r"\blists?\b", r"\blisting\b", r"launchpool",
        r"launchpad", r"hodler airdrop", r"new crypto", r"spot trading for",
        r"introduc\w+ .*\(\w+\)", r"adds? \w+.* to (?:spot|innovation|alpha)",
    ]),
    ("futures_launch", "medium", [
        r"perpetual", r"usd[ⓢs]?-?m", r"futures (?:launch|listing)", r"will launch .*contract",
        r"pre-market", r"premarket",
    ]),
    ("monitoring_tag", "medium", [r"monitoring tag", r"seed tag", r"caution", r"investment warning"]),
    ("token_event", "medium", [
        r"token swap", r"rebrand", r"redenomination", r"mainnet", r"hard fork", r"airdrop",
        r"unlock", r"burn",
    ]),
    ("maintenance", "low", [
        r"maintenance", r"suspen\w+ (?:of )?deposit", r"suspen\w+ (?:of )?withdraw",
        r"network upgrade", r"wallet", r"deposit", r"withdraw",
    ]),
    ("campaign", "low", [r"campaign", r"promotion", r"\bwin\b", r"giveaway", r"rewards?", r"competition"]),
]

# Подсказки от самих бирж весомее наших регулярок
HINT_MAP = {
    # Bybit type.key
    "new_crypto": ("listing", "high"),
    "delistings": ("delisting", "high"),
    "latest_activities": ("campaign", "low"),
    "maintenance_updates": ("maintenance", "low"),
    # OKX annType
    "announcements-new-listings": ("listing", "high"),
    "announcements-delistings": ("delisting", "high"),
    "announcements-deposit-withdrawal-suspension-resumption": ("maintenance", "low"),
    "announcements-latest-events": ("campaign", "low"),
}

_COMPILED = [(cat, imp, [re.compile(p, re.I) for p in pats]) for cat, imp, pats in RULES]

STOP_WORDS = {
    "USDT", "USDC", "USD", "BTC", "ETH", "UTC", "KRW", "API", "VIP", "NFT", "APR", "APY",
    "OTC", "KYC", "AMA", "FAQ", "TGE", "USDⓈ", "UM", "CM", "P2P", "DEX", "CEX", "EVM",
    "ERC", "BEP", "SPL", "TRC", "AI", "ID", "OR", "AND", "THE", "NEW", "FOR",
}
# BTC/ETH сами по себе — частые и важные; убираем их из стоп-слов только в скобках
_PAREN = re.compile(r"\(([A-Z0-9]{2,12})\)")
_PAIR = re.compile(r"\b([A-Z0-9]{2,12})(?:USDT|USDC|/USDT|-USDT)\b")
_DOLLAR = re.compile(r"\$([A-Z][A-Z0-9]{1,11})\b")


def extract_tickers(text: str) -> list:
    found = []

    def add(t):
        if t not in found and not t.isdigit():
            found.append(t)

    for m in _PAREN.finditer(text):
        t = m.group(1)
        if t not in STOP_WORDS or t in ("BTC", "ETH"):
            add(t)
    for rx in (_PAIR, _DOLLAR):
        for m in rx.finditer(text):
            t = m.group(1)
            if t not in STOP_WORDS:
                add(t)
    return found[:10]


def classify(title: str, hint: str = "", body: str = "") -> tuple:
    """Возвращает (категория, важность)."""
    text = f"{title}\n{body[:500]}"
    by_rule = None
    for cat, imp, rxs in _COMPILED:
        if any(rx.search(text) for rx in rxs):
            by_rule = (cat, imp)
            break
    by_hint = HINT_MAP.get(hint)
    if by_hint and by_rule:
        # Взлом или делистинг в тексте важнее общей подсказки биржи
        return by_rule if IMPORTANCE_ORDER[by_rule[1]] > IMPORTANCE_ORDER[by_hint[1]] else by_hint
    return by_hint or by_rule or ("other", "low")


def important_enough(importance: str, minimum: str) -> bool:
    return IMPORTANCE_ORDER.get(importance, 0) >= IMPORTANCE_ORDER.get(minimum, 1)
