"""Настройки берутся из переменных окружения (файл .env подхватывает systemd)."""
import os
from dataclasses import dataclass, field


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _float(name: str, default: float) -> float:
    try:
        return float(_env(name, str(default)))
    except ValueError:
        return default


@dataclass
class Config:
    # Telegram
    tg_token: str = field(default_factory=lambda: _env("TG_BOT_TOKEN"))
    tg_chat_id: str = field(default_factory=lambda: _env("TG_CHAT_ID"))

    # Хранилище
    db_path: str = field(default_factory=lambda: _env("DB_PATH", "data/monitor.db"))

    # Частота опроса анонсов, секунды (OKX: лимит 5 запросов / 2 с)
    bybit_poll_sec: float = field(default_factory=lambda: _float("BYBIT_POLL_SEC", 1.0))
    okx_poll_sec: float = field(default_factory=lambda: _float("OKX_POLL_SEC", 1.0))

    # Binance Announcements WebSocket (необязательно, нужен API-ключ)
    binance_api_key: str = field(default_factory=lambda: _env("BINANCE_API_KEY"))
    binance_api_secret: str = field(default_factory=lambda: _env("BINANCE_API_SECRET"))

    # Минимальная важность события для уведомления: low / medium / high
    alert_min_importance: str = field(default_factory=lambda: _env("ALERT_MIN_IMPORTANCE", "medium"))

    # Через сколько секунд молчания источник считается упавшим
    source_dead_sec: float = field(default_factory=lambda: _float("SOURCE_DEAD_SEC", 90))

    # Горизонты замера реакции цены, минуты
    horizons_min: tuple = (1, 5, 30, 60)

    # Адреса потоков цен (проверить по актуальной документации бирж)
    binance_futures_ws: str = field(default_factory=lambda: _env(
        "BINANCE_FUTURES_WS", "wss://fstream.binance.com/ws/!markPrice@arr@1s"))
    binance_spot_ws: str = field(default_factory=lambda: _env(
        "BINANCE_SPOT_WS", "wss://stream.binance.com:9443/ws/!miniTicker@arr"))
    bybit_tickers_url: str = "https://api.bybit.com/v5/market/tickers?category=linear"
    bybit_announcements_url: str = "https://api.bybit.com/v5/announcements/index?locale=en-US&limit=20"
    okx_announcements_url: str = "https://www.okx.com/api/v5/support/announcements"
    binance_announcements_ws: str = "wss://api.binance.com/sapi/wss"

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.tg_token and self.tg_chat_id)
