"""Журнал событий и реакций цены (SQLite, режим WAL)."""
import json
import os
import sqlite3
from typing import Optional

from .models import Event

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source        TEXT NOT NULL,
    ext_id        TEXT NOT NULL,
    title         TEXT NOT NULL,
    url           TEXT,
    hint          TEXT,
    category      TEXT,
    importance    TEXT,
    tickers       TEXT,           -- JSON-список
    prices        TEXT,           -- JSON: тикер -> цена в момент получения
    published_ms  INTEGER,
    received_ms   INTEGER NOT NULL,
    latency_ms    INTEGER,
    backfill      INTEGER DEFAULT 0,   -- 1 = найдено при первом запуске, не «живое»
    UNIQUE(source, ext_id)
);
CREATE INDEX IF NOT EXISTS ix_events_received ON events(received_ms);

CREATE TABLE IF NOT EXISTS reactions (
    event_id     INTEGER NOT NULL,
    ticker       TEXT NOT NULL,
    horizon_min  INTEGER NOT NULL,
    price        REAL,
    ret_pct      REAL,
    measured_ms  INTEGER NOT NULL,
    PRIMARY KEY (event_id, ticker, horizon_min)
);
"""


class Store:
    def __init__(self, path: str):
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def has_source(self, source: str) -> bool:
        cur = self.conn.execute("SELECT 1 FROM events WHERE source=? LIMIT 1", (source,))
        return cur.fetchone() is not None

    def known_ids(self, source: str, limit: int = 2000) -> set:
        cur = self.conn.execute(
            "SELECT ext_id FROM events WHERE source=? ORDER BY id DESC LIMIT ?", (source, limit))
        return {r[0] for r in cur}

    def insert_event(self, ev: Event, backfill: bool = False) -> Optional[int]:
        try:
            cur = self.conn.execute(
                """INSERT INTO events (source, ext_id, title, url, hint, category, importance,
                   tickers, prices, published_ms, received_ms, latency_ms, backfill)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (ev.source, ev.ext_id, ev.title, ev.url, ev.hint, ev.category, ev.importance,
                 json.dumps(ev.tickers), json.dumps(ev.prices), ev.published_ms, ev.received_ms,
                 ev.latency_ms, int(backfill)))
            self.conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            return None

    def due_reactions(self, now_ms: int, horizons, grace_min: int = 15):
        """Живые события, у которых наступило время замера, а замера ещё нет."""
        out = []
        for h in horizons:
            due_before = now_ms - h * 60_000
            too_old = now_ms - (h + grace_min) * 60_000
            cur = self.conn.execute(
                """SELECT id, tickers, prices, received_ms FROM events
                   WHERE backfill=0 AND received_ms<=? AND received_ms>=? AND prices!='{}'""",
                (due_before, too_old))
            for eid, tickers, prices, rec in cur.fetchall():
                prices = json.loads(prices)   # тикер -> [цена, "площадка:символ"]
                for t in json.loads(tickers):
                    if t not in prices:
                        continue
                    done = self.conn.execute(
                        "SELECT 1 FROM reactions WHERE event_id=? AND ticker=? AND horizon_min=?",
                        (eid, t, h)).fetchone()
                    if not done:
                        base, key = prices[t]
                        out.append((eid, t, h, base, key))
        return out

    def insert_reaction(self, event_id, ticker, horizon, price, base, now_ms):
        ret = (price / base - 1) * 100 if price and base else None
        self.conn.execute(
            "INSERT OR IGNORE INTO reactions VALUES (?,?,?,?,?,?)",
            (event_id, ticker, horizon, price, ret, now_ms))
        self.conn.commit()
        return ret
