"""Обработка событий, замер реакции цены и контроль здоровья источников.

Здесь нет сетевого кода, поэтому модуль тестируется без aiohttp.
"""
import asyncio
import logging
import time

from .classify import classify, extract_tickers, important_enough
from .models import Event
from .formatting import esc, format_event

log = logging.getLogger("pipeline")

STALE_PUBLISH_MS = 60 * 60_000   # анонсы старше часа не считаем «живыми»


def now_ms() -> int:
    return int(time.time() * 1000)


class Health:
    def __init__(self, notifier, dead_after_sec: float):
        self.notifier = notifier
        self.dead_after_ms = dead_after_sec * 1000
        self.last_ok = {}
        self.last_err = {}
        self.dead = set()

    def beat(self, name: str):
        self.last_ok[name] = now_ms()
        if name in self.dead:
            self.dead.discard(name)
            self.notifier.send(f"✅ Источник <b>{esc(name)}</b> снова работает")

    def fail(self, name: str, err: str):
        self.last_err[name] = err
        self.last_ok.setdefault(name, now_ms())   # отсчёт молчания с первой ошибки

    def check(self, extra: dict = None):
        t = now_ms()
        sources = dict(self.last_ok)
        sources.update(extra or {})
        for name, ok in sources.items():
            if ok and t - ok > self.dead_after_ms and name not in self.dead:
                self.dead.add(name)
                err = self.last_err.get(name, "нет данных")
                self.notifier.send(
                    f"🛑 Источник <b>{esc(name)}</b> молчит {int((t - ok) / 1000)} с\n{esc(err)[:300]}")


class Pipeline:
    def __init__(self, cfg, store, book, notifier):
        self.cfg = cfg
        self.store = store
        self.book = book
        self.notifier = notifier
        self.seen = {}           # источник -> множество ext_id
        self.baseline = {}       # источник -> нужна ли базовая загрузка без уведомлений

    def _source_state(self, source):
        if source not in self.seen:
            self.seen[source] = self.store.known_ids(source)
            self.baseline[source] = not self.store.has_source(source)

    def handle_batch(self, source, raws, received_ms, can_baseline=True):
        """Возвращает список новых событий, по которым ушло уведомление."""
        self._source_state(source)
        is_baseline = can_baseline and self.baseline[source]
        alerted = []
        for raw in raws:
            if raw.ext_id in self.seen[source]:
                continue
            self.seen[source].add(raw.ext_id)
            ev = self.build_event(raw, received_ms)
            stale = ev.published_ms is not None and received_ms - ev.published_ms > STALE_PUBLISH_MS
            backfill = is_baseline or stale
            ev_id = self.store.insert_event(ev, backfill=backfill)
            if ev_id is None or backfill:
                continue
            log.info("НОВОЕ %s [%s/%s] %s", source, ev.category, ev.importance, ev.title)
            if important_enough(ev.importance, self.cfg.alert_min_importance):
                self.notifier.send(format_event(ev))
                alerted.append(ev)
        if is_baseline:
            self.baseline[source] = False
            log.info("%s: базовая загрузка %d анонсов (без уведомлений)", source, len(raws))
        return alerted

    def build_event(self, raw, received_ms) -> Event:
        category, importance = classify(raw.title, raw.hint, raw.body)
        tickers = extract_tickers(f"{raw.title} {raw.body[:500]}")
        prices = {}
        for t in tickers:
            found = self.book.lookup(t)
            if found:
                prices[t] = [found[0], found[1]]
        return Event(**raw.__dict__, received_ms=received_ms, category=category,
                     importance=importance, tickers=tickers, prices=prices)

    def measure_reactions(self):
        """Дописывает цены через 1/5/30/60 минут. Безопасно при перезапуске."""
        t = now_ms()
        for eid, ticker, horizon, base, key in self.store.due_reactions(t, self.cfg.horizons_min):
            price = self.book.get_key(key)
            ret = self.store.insert_reaction(eid, ticker, horizon, price, base, t)
            if ret is not None and horizon in (5, 30):
                self.notifier.send(f"↳ #{eid} {esc(ticker)}: {ret:+.2f}% за {horizon} мин")


async def run_pipeline(pipe: Pipeline, queue: asyncio.Queue, stop: asyncio.Event):
    while not stop.is_set():
        source, raws, received, can_baseline = await queue.get()
        try:
            pipe.handle_batch(source, raws, received, can_baseline)
        except Exception:
            log.exception("ошибка обработки пачки %s", source)


async def run_periodic(pipe: Pipeline, health: Health, stop: asyncio.Event):
    while not stop.is_set():
        try:
            pipe.measure_reactions()
            # потоки цен тоже проверяем на «молчание»
            health.check({f"prices-{v}": ts for v, ts in pipe.book.last_update.items() if ts})
        except Exception:
            log.exception("ошибка периодической задачи")
        await asyncio.sleep(5)
