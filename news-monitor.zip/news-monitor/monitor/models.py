from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RawEvent:
    """Событие в едином формате, как его отдаёт сборщик."""
    source: str              # bybit / okx / binance
    ext_id: str              # уникальный ID внутри источника (обычно URL)
    title: str
    url: str = ""
    published_ms: Optional[int] = None   # время публикации по данным источника
    hint: str = ""           # тип/категория от самой биржи (new_crypto, annType…)
    body: str = ""


@dataclass
class Event(RawEvent):
    received_ms: int = 0
    category: str = "other"
    importance: str = "low"
    tickers: list = field(default_factory=list)
    prices: dict = field(default_factory=dict)   # тикер -> цена в момент получения

    @property
    def latency_ms(self) -> Optional[int]:
        if self.published_ms is None:
            return None
        return self.received_ms - self.published_ms
