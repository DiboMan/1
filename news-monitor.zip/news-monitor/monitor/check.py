"""Проверка сервера перед покупкой: python -m monitor.check

Показывает, отвечают ли биржи с этого IP и с какой задержкой.
"""
import asyncio
import time

import aiohttp

TARGETS = [
    ("Bybit анонсы", "https://api.bybit.com/v5/announcements/index?locale=en-US&limit=1"),
    ("Bybit цены", "https://api.bybit.com/v5/market/tickers?category=linear&symbol=BTCUSDT"),
    ("OKX анонсы", "https://www.okx.com/api/v5/support/announcements"),
    ("Binance Futures", "https://fapi.binance.com/fapi/v1/ping"),
    ("Binance Spot", "https://api.binance.com/api/v3/ping"),
    ("Telegram", "https://api.telegram.org"),
]


async def probe(session, name, url):
    times, status = [], None
    for _ in range(5):
        t = time.perf_counter()
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
                await r.read()
                status = r.status
            times.append((time.perf_counter() - t) * 1000)
        except Exception as e:
            status = type(e).__name__
    best = f"{min(times):6.0f} мс" if times else "     —"
    ok = "OK " if status in (200, 302) else "!! "
    print(f"{ok}{name:<16} статус {str(status):<20} лучшее время {best}")


async def main():
    async with aiohttp.ClientSession() as s:
        for name, url in TARGETS:
            await probe(s, name, url)
    print("\n«!!» с кодом 403 или 451 — биржа блокирует IP этого сервера, нужен другой провайдер.")


if __name__ == "__main__":
    asyncio.run(main())
