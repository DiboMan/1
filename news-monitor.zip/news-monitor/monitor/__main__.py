"""Запуск: python launcher.py (на сервере) или python -m monitor"""
import asyncio
import logging
import os
import signal
import time
from types import SimpleNamespace

from . import __version__, updater
from .collectors import run_collectors
from .commands import Commands
from .config import Config
from .db import Store
from .notifier import Notifier
from .pipeline import Health, Pipeline, run_periodic, run_pipeline
from .prices import PriceBook, run_prices

STABLE_AFTER_SEC = 60   # столько должна проработать новая версия, чтобы считаться успешной


async def confirm_update(notifier, stop):
    flag = updater.read_flag(os.getcwd())
    if not flag:
        return
    try:
        await asyncio.wait_for(stop.wait(), timeout=STABLE_AFTER_SEC)
        return          # остановились раньше — не подтверждаем
    except asyncio.TimeoutError:
        pass
    updater.clear_flag(os.getcwd())
    notifier.send(f"✅ Версия {__version__} работает стабильно {STABLE_AFTER_SEC} с — обновление завершено")


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = Config()
    store = Store(cfg.db_path)
    book = PriceBook()
    notifier = Notifier(cfg)
    health = Health(notifier, cfg.source_dead_sec)
    pipe = Pipeline(cfg, store, book, notifier)
    queue: asyncio.Queue = asyncio.Queue()
    stop = asyncio.Event()
    ctx = SimpleNamespace(store=store, book=book, health=health, stop=stop,
                          started=time.time(), restart_requested=False)

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    notifier.send(f"🚀 Новостной монитор {__version__} запущен. /help — команды")
    tasks = [
        asyncio.create_task(notifier.run(stop)),
        asyncio.create_task(run_prices(cfg, book, stop)),
        asyncio.create_task(run_pipeline(pipe, queue, stop)),
        asyncio.create_task(run_periodic(pipe, health, stop)),
        asyncio.create_task(Commands(cfg, ctx).run()),
        asyncio.create_task(confirm_update(notifier, stop)),
    ]
    # даём ценам 5 секунд загрузиться, чтобы первые события уже были с ценой
    try:
        await asyncio.wait_for(stop.wait(), timeout=5)
    except asyncio.TimeoutError:
        tasks.append(asyncio.create_task(run_collectors(cfg, queue, health, stop)))

    await stop.wait()
    # даём уйти последним сообщениям в Telegram
    for _ in range(30):
        if notifier.queue.empty():
            break
        await asyncio.sleep(0.1)
    await asyncio.sleep(0.5)
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    store.conn.close()
    if ctx.restart_requested:
        logging.info("перезапуск по команде")


if __name__ == "__main__":
    asyncio.run(main())
