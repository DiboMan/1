"""Запуск: python -m monitor"""
import asyncio
import logging
import signal

from .collectors import run_collectors
from .config import Config
from .db import Store
from .notifier import Notifier
from .pipeline import Health, Pipeline, run_periodic, run_pipeline
from .prices import PriceBook, run_prices


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = Config()
    store = Store(cfg.db_path)
    book = PriceBook()
    notifier = Notifier(cfg)
    health = Health(notifier, cfg.source_dead_sec)
    pipe = Pipeline(cfg, store, book, notifier)
    queue: asyncio.Queue = asyncio.Queue()
    stop = asyncio.Event()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    notifier.send("🚀 Новостной монитор запущен")
    # даём ценам 5 секунд загрузиться, чтобы первые события уже были с ценой
    tasks = [
        asyncio.create_task(notifier.run(stop)),
        asyncio.create_task(run_prices(cfg, book, stop)),
        asyncio.create_task(run_pipeline(pipe, queue, stop)),
        asyncio.create_task(run_periodic(pipe, health, stop)),
    ]
    await asyncio.sleep(5)
    tasks.append(asyncio.create_task(run_collectors(cfg, queue, health, stop)))

    await stop.wait()
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    store.conn.close()


if __name__ == "__main__":
    asyncio.run(main())
