"""Отчёт по накопленной статистике: python -m monitor.stats [путь к базе]"""
import sqlite3
import statistics
import sys


def pct(values, q):
    if not values:
        return None
    values = sorted(values)
    return values[min(len(values) - 1, int(q * len(values)))]


def report(db_path: str) -> str:
    conn = sqlite3.connect(db_path)
    out = []

    out.append("ЗАДЕРЖКА ИСТОЧНИКОВ (живые события), секунды")
    out.append(f"{'источник':<10}{'n':>6}{'медиана':>10}{'p95':>10}")
    for (src,) in conn.execute("SELECT DISTINCT source FROM events"):
        lat = [r[0] / 1000 for r in conn.execute(
            "SELECT latency_ms FROM events WHERE source=? AND backfill=0 AND latency_ms IS NOT NULL",
            (src,))]
        if lat:
            out.append(f"{src:<10}{len(lat):>6}{statistics.median(lat):>10.1f}{pct(lat, .95):>10.1f}")

    out.append("")
    out.append("РЕАКЦИЯ ЦЕНЫ ПО ТИПАМ СОБЫТИЙ, %")
    out.append(f"{'категория':<16}{'мин':>5}{'n':>5}{'среднее':>10}{'медиана':>10}{'|ср.|':>8}{'вверх':>8}")
    rows = conn.execute("""
        SELECT e.category, r.horizon_min, r.ret_pct FROM reactions r
        JOIN events e ON e.id = r.event_id WHERE r.ret_pct IS NOT NULL
        ORDER BY e.category, r.horizon_min""").fetchall()
    groups = {}
    for cat, h, ret in rows:
        groups.setdefault((cat, h), []).append(ret)
    for (cat, h), rets in groups.items():
        up = sum(1 for r in rets if r > 0) / len(rets) * 100
        mean_abs = sum(abs(r) for r in rets) / len(rets)
        out.append(f"{cat:<16}{h:>5}{len(rets):>5}{statistics.mean(rets):>10.2f}"
                   f"{statistics.median(rets):>10.2f}{mean_abs:>8.2f}{up:>7.0f}%")
    if not groups:
        out.append("(пока нет замеров)")

    total = conn.execute("SELECT COUNT(*), SUM(backfill=0) FROM events").fetchone()
    out.append("")
    out.append(f"Всего событий: {total[0]}, из них живых: {total[1] or 0}")
    conn.close()
    return "\n".join(out)


if __name__ == "__main__":
    print(report(sys.argv[1] if len(sys.argv) > 1 else "data/monitor.db"))
