"""Команды Telegram-бота. Отвечает только владельцу (TG_CHAT_ID)."""
import asyncio
import html
import logging
import os
import time

import aiohttp

from . import __version__
from . import updater
from .stats import report

log = logging.getLogger("commands")

HELP = (
    "<b>Команды</b>\n"
    "/status — состояние источников и цен\n"
    "/last — последние 5 живых событий\n"
    "/stats — статистика задержек и реакции цены\n"
    "/restart — перезапуск\n"
    "/rollback — вернуть прошлую версию\n"
    "/version — текущая версия\n\n"
    "<b>Обновление:</b> пришлите сюда файл news-monitor.zip — бот проверит код, "
    "сохранит резервную копию и перезапустится. Если новая версия не стартует, "
    "прошлая вернётся автоматически."
)


def _ago(ms_ts):
    if not ms_ts:
        return "нет данных"
    s = int(time.time() - ms_ts / 1000)
    return f"{s} с назад" if s < 120 else f"{s // 60} мин назад"


class Commands:
    def __init__(self, cfg, ctx):
        self.cfg = cfg
        self.ctx = ctx              # store, book, health, stop, started, restart_requested
        self.api = f"https://api.telegram.org/bot{cfg.tg_token}"
        self.app_dir = os.getcwd()

    async def run(self):
        if not self.cfg.telegram_enabled:
            return
        offset = None
        async with aiohttp.ClientSession() as session:
            self.session = session
            # пропускаем сообщения, накопившиеся пока бот был выключен
            try:
                async with session.get(f"{self.api}/getUpdates", params={"offset": -1}) as r:
                    upd = (await r.json()).get("result") or []
                    if upd:
                        offset = upd[-1]["update_id"] + 1
            except Exception as e:
                log.warning("getUpdates (старт): %s", e)
            while not self.ctx.stop.is_set():
                try:
                    params = {"timeout": 25, "allowed_updates": '["message"]'}
                    if offset:
                        params["offset"] = offset
                    async with session.get(f"{self.api}/getUpdates", params=params,
                                           timeout=aiohttp.ClientTimeout(total=35)) as r:
                        data = await r.json()
                    for upd in data.get("result") or []:
                        offset = upd["update_id"] + 1
                        msg = upd.get("message") or {}
                        if str((msg.get("chat") or {}).get("id")) != str(self.cfg.tg_chat_id):
                            continue    # чужие чаты игнорируем
                        await self.handle(msg)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.warning("getUpdates: %s", e)
                    await asyncio.sleep(3)

    async def reply(self, text, pre=False):
        if pre:
            text = "<pre>" + html.escape(text) + "</pre>"
        try:
            await self.session.post(f"{self.api}/sendMessage", json={
                "chat_id": self.cfg.tg_chat_id, "text": text[:4000], "parse_mode": "HTML",
                "disable_web_page_preview": True})
        except Exception as e:
            log.warning("reply: %s", e)

    async def handle(self, msg):
        doc = msg.get("document")
        if doc:
            await self.handle_update(doc)
            return
        cmd = (msg.get("text") or "").strip().split()[0:1]
        cmd = cmd[0].split("@")[0].lower() if cmd else ""
        if cmd in ("/start", "/help"):
            await self.reply(HELP)
        elif cmd == "/version":
            await self.reply(f"Версия {__version__}")
        elif cmd == "/status":
            await self.reply(self.status_text())
        elif cmd == "/last":
            await self.reply(self.last_text())
        elif cmd == "/stats":
            await self.reply(report(self.cfg.db_path), pre=True)
        elif cmd == "/restart":
            await self.reply("🔄 Перезапускаюсь…")
            self.restart()
        elif cmd == "/rollback":
            try:
                v = updater.rollback(self.app_dir)
                await self.reply(f"↩️ Возвращаю версию {v['new']} (была {v['old']}), перезапуск…")
                self.restart()
            except updater.UpdateError as e:
                await self.reply(f"Откат невозможен: {html.escape(str(e))}")
        elif cmd:
            await self.reply("Не знаю такой команды. /help — список.")

    def restart(self):
        # systemd (Restart=always) поднимет процесс заново
        self.ctx.restart_requested = True
        self.ctx.stop.set()

    async def handle_update(self, doc):
        name = doc.get("file_name") or ""
        if not name.lower().endswith(".zip"):
            await self.reply("Для обновления нужен zip-архив.")
            return
        if (doc.get("file_size") or 0) > updater.MAX_ZIP_BYTES:
            await self.reply("Архив больше 20 МБ — Telegram не даст его скачать.")
            return
        await self.reply(f"📦 Получил {html.escape(name)}, проверяю…")
        try:
            async with self.session.get(f"{self.api}/getFile",
                                        params={"file_id": doc["file_id"]}) as r:
                path = (await r.json())["result"]["file_path"]
            url = f"https://api.telegram.org/file/bot{self.cfg.tg_token}/{path}"
            async with self.session.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                blob = await r.read()
            v = await asyncio.to_thread(updater.apply_update, blob, self.app_dir)
        except updater.UpdateError as e:
            await self.reply(f"❌ Обновление отклонено: {html.escape(str(e))}\nРаботает прежняя версия.")
            return
        except Exception as e:
            log.exception("update")
            await self.reply(f"❌ Не удалось обновить: {html.escape(str(e))}\nРаботает прежняя версия.")
            return
        await self.reply(f"✅ Код обновлён: {v['old']} → {v['new']}. Перезапускаюсь…")
        self.restart()

    def status_text(self):
        c = self.ctx
        up = int(time.time() - c.started)
        lines = [f"<b>Монитор {__version__}</b> · работает {up // 3600} ч {up % 3600 // 60} мин", ""]
        lines.append("<b>Источники анонсов</b>")
        for name, ts in sorted(c.health.last_ok.items()):
            mark = "🛑" if name in c.health.dead else "✅"
            lines.append(f"{mark} {name}: {_ago(ts)}")
        lines.append("")
        lines.append("<b>Цены</b>")
        names = {"bnf": "Binance Futures", "bns": "Binance Spot", "byb": "Bybit"}
        for v, ts in c.book.last_update.items():
            lines.append(f"{'✅' if ts else '⏳'} {names.get(v, v)}: {_ago(ts)}")
        lines.append(f"Монет в книге цен: {len(c.book.prices)}")
        day_ago = int(time.time() * 1000) - 86_400_000
        n = c.store.conn.execute(
            "SELECT COUNT(*) FROM events WHERE backfill=0 AND received_ms>?", (day_ago,)).fetchone()[0]
        lines.append("")
        lines.append(f"Живых событий за сутки: {n}")
        return "\n".join(lines)

    def last_text(self):
        rows = self.ctx.store.conn.execute(
            """SELECT source, category, title, received_ms, latency_ms FROM events
               WHERE backfill=0 ORDER BY id DESC LIMIT 5""").fetchall()
        if not rows:
            return "Живых событий пока не было."
        out = []
        for src, cat, title, rec, lat in rows:
            t = time.strftime("%d.%m %H:%M", time.gmtime(rec / 1000))
            lat_s = f", {lat / 1000:.1f} с" if lat is not None else ""
            out.append(f"• {t} UTC · {html.escape(src)} · {html.escape(cat)}{lat_s}\n{html.escape(title)}")
        return "\n\n".join(out)
