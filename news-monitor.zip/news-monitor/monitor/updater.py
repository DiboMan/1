"""Обновление кода из присланного архива. Только стандартная библиотека.

Порядок: распаковать во временную папку → найти пакет monitor → проверить,
что все файлы компилируются → старый код в monitor.bak → новый на место →
флаг update_pending (по нему launcher откатит версию, если она упадёт при старте).
"""
import io
import json
import os
import py_compile
import re
import shutil
import tempfile
import time
import zipfile

MAX_ZIP_BYTES = 20 * 1024 * 1024


class UpdateError(Exception):
    pass


def read_version(pkg_dir: str) -> str:
    try:
        with open(os.path.join(pkg_dir, "__init__.py"), encoding="utf-8") as f:
            m = re.search(r"__version__\s*=\s*['\"]([^'\"]+)", f.read())
            return m.group(1) if m else "?"
    except OSError:
        return "?"


def _find_root(extracted: str) -> str:
    """Папка, внутри которой лежит пакет monitor (архив может быть с обёрткой news-monitor/)."""
    for root, dirs, files in os.walk(extracted):
        if os.path.basename(root) == "monitor" and "__main__.py" in files:
            return os.path.dirname(root)
    raise UpdateError("в архиве нет папки monitor с __main__.py")


def apply_update(zip_bytes: bytes, app_dir: str) -> dict:
    if len(zip_bytes) > MAX_ZIP_BYTES:
        raise UpdateError("архив больше 20 МБ")
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        raise UpdateError("файл не является zip-архивом")

    with tempfile.TemporaryDirectory() as tmp:
        for info in zf.infolist():
            # защита от путей вида ../../etc
            target = os.path.realpath(os.path.join(tmp, info.filename))
            if not target.startswith(os.path.realpath(tmp) + os.sep):
                raise UpdateError(f"подозрительный путь в архиве: {info.filename}")
        zf.extractall(tmp)
        src_root = _find_root(tmp)
        new_pkg = os.path.join(src_root, "monitor")

        for root, _, files in os.walk(new_pkg):
            for name in files:
                if name.endswith(".py"):
                    path = os.path.join(root, name)
                    try:
                        py_compile.compile(path, doraise=True,
                                           cfile=os.path.join(tmp, "_check.pyc"))
                    except py_compile.PyCompileError as e:
                        raise UpdateError(f"ошибка в коде {name}: {e.msg[-300:]}")

        cur_pkg = os.path.join(app_dir, "monitor")
        bak_pkg = os.path.join(app_dir, "monitor.bak")
        old_version = read_version(cur_pkg)
        new_version = read_version(new_pkg)

        if os.path.isdir(bak_pkg):
            shutil.rmtree(bak_pkg)
        if os.path.isdir(cur_pkg):
            shutil.move(cur_pkg, bak_pkg)
        shutil.copytree(new_pkg, cur_pkg, ignore=shutil.ignore_patterns("__pycache__"))

        # сопутствующие файлы, если есть в архиве
        for extra in ("launcher.py", "requirements.txt"):
            p = os.path.join(src_root, extra)
            if os.path.isfile(p):
                shutil.copy2(p, os.path.join(app_dir, extra))
        if os.path.isdir(os.path.join(src_root, "deploy")):
            shutil.copytree(os.path.join(src_root, "deploy"), os.path.join(app_dir, "deploy"),
                            dirs_exist_ok=True)

    write_flag(app_dir, old_version, new_version)
    return {"old": old_version, "new": new_version}


def rollback(app_dir: str) -> dict:
    cur_pkg = os.path.join(app_dir, "monitor")
    bak_pkg = os.path.join(app_dir, "monitor.bak")
    if not os.path.isdir(bak_pkg):
        raise UpdateError("резервной копии нет")
    old, new = read_version(cur_pkg), read_version(bak_pkg)
    swap = cur_pkg + ".swap"
    shutil.move(cur_pkg, swap)
    shutil.move(bak_pkg, cur_pkg)
    shutil.move(swap, bak_pkg)      # текущую версию сохраняем, можно вернуться обратно
    return {"old": old, "new": new}


def flag_path(app_dir: str) -> str:
    return os.path.join(app_dir, "data", "update_pending")


def write_flag(app_dir: str, old: str, new: str):
    os.makedirs(os.path.join(app_dir, "data"), exist_ok=True)
    with open(flag_path(app_dir), "w") as f:
        json.dump({"old": old, "new": new, "ts": time.time()}, f)


def read_flag(app_dir: str):
    try:
        with open(flag_path(app_dir)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def clear_flag(app_dir: str):
    try:
        os.remove(flag_path(app_dir))
    except OSError:
        pass
