"""Уведомления в Telegram через отдельную очередь, чтобы отправка не тормозила приём событий."""
import asyncio
import logging

import aiohttp

from .formatting import esc, format_event  # noqa: F401

log = logging.getLogger("telegram")


class Notifier:
    def __init__(self, cfg):
        self.cfg = cfg
        self.queue: asyncio.Queue = asyncio.Queue()

    def send(self, text: str):
        if self.cfg.telegram_enabled:
            self.queue.put_nowait(text)
        else:
            log.info("[TG выключен] %s", text.replace("\n", " | "))

    async def run(self, stop: asyncio.Event):
        if not self.cfg.telegram_enabled:
            await stop.wait()
            return
        url = f"https://api.telegram.org/bot{self.cfg.tg_token}/sendMessage"
        async with aiohttp.ClientSession() as session:
            while not stop.is_set():
                text = await self.queue.get()
                for attempt in range(3):
                    try:
                        async with session.post(url, json={
                            "chat_id": self.cfg.tg_chat_id, "text": text, "parse_mode": "HTML",
                            "disable_web_page_preview": True,
                        }, timeout=aiohttp.ClientTimeout(total=10)) as r:
                            if r.status == 429:
                                retry = (await r.json()).get("parameters", {}).get("retry_after", 3)
                                await asyncio.sleep(retry)
                                continue
                            if r.status != 200:
                                log.warning("telegram HTTP %s: %s", r.status, await r.text())
                            break
                    except Exception as e:
                        log.warning("telegram: %s", e)
                        await asyncio.sleep(2)
                await asyncio.sleep(0.05)   # лимит Telegram ~30 сообщений/с
