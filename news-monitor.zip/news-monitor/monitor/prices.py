"""Живые цены по всему рынку: Binance Futures + Binance Spot (WebSocket) и Bybit (REST)."""
import asyncio
import json
import logging
import time
from typing import Optional, Tuple

import aiohttp

log = logging.getLogger("prices")


class PriceBook:
    """Последние цены. Ключ = 'площадка:СИМВОЛ', например 'bnf:SOLUSDT'."""

    VENUES = ("bnf", "bns", "byb")   # порядок приоритета: фьючерсы Binance, спот Binance, Bybit

    def __init__(self):
        self.prices = {}      # key -> (price, ts_ms)
        self.last_update = {v: 0 for v in self.VENUES}

    def set(self, venue: str, symbol: str, price: float, now_ms: int):
        self.prices[f"{venue}:{symbol}"] = (price, now_ms)
        self.last_update[venue] = now_ms

    def get_key(self, key: str, max_age_ms: int = 120_000) -> Optional[float]:
        v = self.prices.get(key)
        if not v:
            return None
        price, ts = v
        if int(time.time() * 1000) - ts > max_age_ms:
            return None
        return price

    def lookup(self, ticker: str) -> Optional[Tuple[float, str]]:
        """Находит цену тикера на лучшей площадке. Возвращает (цена, ключ)."""
        for venue in self.VENUES:
            for sym in (f"{ticker}USDT", f"1000{ticker}USDT", f"{ticker}USDC"):
                key = f"{venue}:{sym}"
                p = self.get_key(key)
                if p:
                    return p, key
        return None


async def _ws_loop(session, url, name, handler, stop: asyncio.Event):
    backoff = 1
    while not stop.is_set():
        try:
            async with session.ws_connect(url, heartbeat=20, max_msg_size=0) as ws:
                log.info("%s: подключено", name)
                backoff = 1
                async for msg in ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        handler(msg.data)
                    elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                        break
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("%s: ошибка %s, переподключение через %s с", name, e, backoff)
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, 30)


async def run_prices(cfg, book: PriceBook, stop: asyncio.Event):
    async with aiohttp.ClientSession() as session:

        def on_futures(raw):
            now = int(time.time() * 1000)
            for it in json.loads(raw):
                try:
                    book.set("bnf", it["s"], float(it["p"]), now)
                except (KeyError, ValueError, TypeError):
                    pass

        def on_spot(raw):
            now = int(time.time() * 1000)
            for it in json.loads(raw):
                try:
                    book.set("bns", it["s"], float(it["c"]), now)
                except (KeyError, ValueError, TypeError):
                    pass

        async def bybit_loop():
            while not stop.is_set():
                try:
                    async with session.get(cfg.bybit_tickers_url,
                                           timeout=aiohttp.ClientTimeout(total=5)) as r:
                        data = await r.json(content_type=None)
                    now = int(time.time() * 1000)
                    for it in (data.get("result") or {}).get("list") or []:
                        try:
                            book.set("byb", it["symbol"], float(it["lastPrice"]), now)
                        except (KeyError, ValueError, TypeError):
                            pass
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.warning("bybit tickers: %s", e)
                await asyncio.sleep(2)

        await asyncio.gather(
            _ws_loop(session, cfg.binance_futures_ws, "binance-futures", on_futures, stop),
            _ws_loop(session, cfg.binance_spot_ws, "binance-spot", on_spot, stop),
            bybit_loop(),
        )
