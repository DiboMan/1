"""Разбор ответов бирж в RawEvent. Без сетевого кода — легко тестировать."""
import json
from typing import List

from .models import RawEvent


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def parse_bybit(payload: dict) -> List[RawEvent]:
    if payload.get("retCode") not in (0, None):
        raise ValueError(f"bybit retCode={payload.get('retCode')} {payload.get('retMsg')}")
    items = (payload.get("result") or {}).get("list") or []
    out = []
    for it in items:
        url = it.get("url") or ""
        title = it.get("title") or ""
        if not (url or title):
            continue
        ts = _int(it.get("publishTime")) or _int(it.get("dateTimestamp"))
        out.append(RawEvent(
            source="bybit", ext_id=url or title, title=title, url=url, published_ms=ts,
            hint=((it.get("type") or {}).get("key") or ""), body=it.get("description") or ""))
    return out


def parse_okx(payload: dict) -> List[RawEvent]:
    if str(payload.get("code", "0")) != "0":
        raise ValueError(f"okx code={payload.get('code')} {payload.get('msg')}")
    out = []
    for page in payload.get("data") or []:
        for it in page.get("details") or []:
            url = it.get("url") or ""
            title = it.get("title") or ""
            if not (url or title):
                continue
            out.append(RawEvent(
                source="okx", ext_id=url or title, title=title, url=url,
                published_ms=_int(it.get("pTime")), hint=it.get("annType") or ""))
    return out


def parse_binance_ws(message: str) -> List[RawEvent]:
    """Сообщение Binance Announcements WS. Поле data часто приходит JSON-строкой."""
    msg = json.loads(message)
    data = msg.get("data", msg)
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except json.JSONDecodeError:
            return []
    if not isinstance(data, dict) or not data.get("title"):
        return []
    title = data["title"]
    ts = _int(data.get("publishDate"))
    ext = str(data.get("id") or data.get("code") or f"{ts}:{title}")
    return [RawEvent(
        source="binance", ext_id=ext, title=title, published_ms=ts,
        hint=str(data.get("catalogName") or ""), body=data.get("body") or "",
        url="https://www.binance.com/en/support/announcement")]
