"""Форматирование сообщений (без сетевого кода)."""
import html


def esc(s) -> str:
    return html.escape(str(s), quote=False)


ICONS = {"listing": "🟢", "delisting": "🔴", "hack": "🚨", "futures_launch": "📈",
         "monitoring_tag": "⚠️", "token_event": "🔄", "maintenance": "🔧", "campaign": "🎁"}


def format_event(ev) -> str:
    icon = ICONS.get(ev.category, "📰")
    lines = [f"{icon} <b>{esc(ev.source.upper())}</b> · {esc(ev.category)} · {esc(ev.importance)}",
             esc(ev.title)]
    if ev.prices:
        parts = [f"{esc(t)} {p[0]:g} ({esc(p[1].split(':')[0])})" for t, p in ev.prices.items()]
        lines.append("Цена: " + ", ".join(parts))
    elif ev.tickers:
        lines.append("Тикеры: " + ", ".join(esc(t) for t in ev.tickers) + " (цены нет на Binance/Bybit)")
    if ev.latency_ms is not None:
        lines.append(f"Задержка: {ev.latency_ms / 1000:.1f} с")
    if ev.url:
        lines.append(f'<a href="{esc(ev.url)}">Открыть</a>')
    return "\n".join(lines)
