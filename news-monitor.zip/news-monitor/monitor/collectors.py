"""Сборщики анонсов. Каждый кладёт RawEvent в общую очередь и отмечает «пульс» источника."""
import asyncio
import hashlib
import hmac
import logging
import time
import uuid
from urllib.parse import urlencode

import aiohttp

from .parsers import parse_binance_ws, parse_bybit, parse_okx

log = logging.getLogger("collectors")

HEADERS = {"User-Agent": "Mozilla/5.0 (news-monitor)", "Accept-Language": "en-US"}


async def poll_rest(session, name, url, parser, interval, queue, health, stop):
    """Опрос REST-эндпоинта. Отдаёт в очередь всё из ответа — дубликаты отсеет pipeline."""
    while not stop.is_set():
        started = time.monotonic()
        try:
            async with session.get(url, headers=HEADERS,
                                   timeout=aiohttp.ClientTimeout(total=5)) as r:
                if r.status != 200:
                    raise RuntimeError(f"HTTP {r.status}")
                payload = await r.json(content_type=None)
            received = int(time.time() * 1000)
            await queue.put((name, parser(payload), received, True))
            health.beat(name)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            health.fail(name, str(e))
            log.warning("%s: %s", name, e)
        elapsed = time.monotonic() - started
        await asyncio.sleep(max(0.0, interval - elapsed))


def _binance_signed_url(cfg) -> str:
    params = {
        "random": uuid.uuid4().hex,
        "topic": "com_announcement_en",
        "recvWindow": 30000,
        "timestamp": int(time.time() * 1000),
    }
    query = urlencode(params)
    sig = hmac.new(cfg.binance_api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
    return f"{cfg.binance_announcements_ws}?{query}&signature={sig}"


async def binance_ws(session, cfg, queue, health, stop):
    """Binance Announcements: push сразу при публикации. Нужны API-ключ и секрет."""
    backoff = 1
    while not stop.is_set():
        try:
            async with session.ws_connect(_binance_signed_url(cfg), heartbeat=20,
                                          headers={"X-MBX-APIKEY": cfg.binance_api_key}) as ws:
                log.info("binance announcements: подключено")
                health.beat("binance")
                backoff = 1
                async for msg in ws:
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                            break
                        continue
                    received = int(time.time() * 1000)
                    health.beat("binance")
                    try:
                        events = parse_binance_ws(msg.data)
                        if events:
                            # push-источник присылает только новое: базовой загрузки нет
                            await queue.put(("binance", events, received, False))
                    except Exception as e:
                        log.warning("binance: не разобрал сообщение: %s | %s", e, msg.data[:300])
        except asyncio.CancelledError:
            raise
        except Exception as e:
            health.fail("binance", str(e))
            log.warning("binance announcements: %s", e)
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, 60)


async def run_collectors(cfg, queue, health, stop):
    async with aiohttp.ClientSession() as session:
        tasks = [
            poll_rest(session, "bybit", cfg.bybit_announcements_url, parse_bybit,
                      cfg.bybit_poll_sec, queue, health, stop),
            poll_rest(session, "okx", cfg.okx_announcements_url, parse_okx,
                      cfg.okx_poll_sec, queue, health, stop),
        ]
        if cfg.binance_api_key and cfg.binance_api_secret:
            tasks.append(binance_ws(session, cfg, queue, health, stop))
        else:
            log.info("binance announcements: ключ не задан, источник выключен")
        await asyncio.gather(*tasks)
