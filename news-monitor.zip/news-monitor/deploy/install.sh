#!/usr/bin/env bash
# Установка на Ubuntu/Debian. Запуск из папки проекта: sudo bash deploy/install.sh
set -euo pipefail

APP=/opt/news-monitor

apt-get update
apt-get install -y python3 python3-venv chrony   # chrony — точное время, важно для замера задержки
systemctl enable --now chrony

id monitor &>/dev/null || useradd --system --home "$APP" --shell /usr/sbin/nologin monitor
mkdir -p "$APP"
cp -r monitor deploy requirements.txt launcher.py "$APP"/
[ -f "$APP/.env" ] || cp .env.example "$APP/.env"

python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install -r "$APP/requirements.txt"
mkdir -p "$APP/data"
chown -R monitor:monitor "$APP"
chmod 600 "$APP/.env"

cp deploy/news-monitor.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable news-monitor

echo
echo "Готово. Дальше:"
echo "  1) nano $APP/.env        — впишите TG_BOT_TOKEN и TG_CHAT_ID"
echo "  2) systemctl start news-monitor"
echo "  3) journalctl -u news-monitor -f   — живой лог"
