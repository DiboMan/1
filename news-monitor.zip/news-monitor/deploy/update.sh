#!/usr/bin/env bash
# Обновление кода без потери базы и .env: bash update.sh [ссылка на архив]
set -euo pipefail

URL="${1:-https://github.com/DiboMan/1/raw/main/news-monitor.zip}"
APP=/opt/news-monitor
TMP=$(mktemp -d)

wget -q -O "$TMP/nm.zip" "$URL"
unzip -q "$TMP/nm.zip" -d "$TMP"
SRC="$TMP/news-monitor"

rm -rf "$APP/monitor"
cp -r "$SRC/monitor" "$SRC/deploy" "$SRC/requirements.txt" "$SRC/launcher.py" "$APP"/
cp "$SRC/deploy/news-monitor.service" /etc/systemd/system/ && systemctl daemon-reload
"$APP/venv/bin/pip" install -q -r "$APP/requirements.txt"
chown -R monitor:monitor "$APP"
rm -rf "$TMP"

systemctl restart news-monitor
echo "Обновлено и перезапущено. Лог: journalctl -u news-monitor -f"
